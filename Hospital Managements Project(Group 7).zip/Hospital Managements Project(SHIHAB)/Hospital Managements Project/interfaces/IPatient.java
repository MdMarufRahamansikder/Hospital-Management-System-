package interfaces;

import java.lang.*;
import classes.*;

public interface IPatient
{
	void addPatient(String a);
	void removePatient(String a);
    void searchPatient(String a);
	void showPatientInfo();
}