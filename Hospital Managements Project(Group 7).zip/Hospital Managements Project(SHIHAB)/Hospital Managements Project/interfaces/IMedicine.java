package interfaces;

import java.lang.*;
import classes.*;

public interface IMedicine
{
	
    void addMedicine(String a);
	void removeMedicine(String a);
    void searchMedicine(String a);
	void showMedicine();

}