package interfaces;

import java.lang.*;
import classes.*;

public interface IDoctor
{
	
    void addDoctor(String a);
	void removeDoctor(String a);
	void searchDoctor(String a);
	void showDoctorlist();

}