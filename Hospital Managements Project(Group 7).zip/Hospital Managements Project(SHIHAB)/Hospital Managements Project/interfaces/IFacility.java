package interfaces;

import java.lang.*;
import classes.*;

public interface IFacility
{
	
    void addFacility(String a);
	void removeFacility(String a);
    void searchFacility(String a);
    void showFacilities();
}