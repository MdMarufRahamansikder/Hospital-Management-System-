package interfaces;

import java.lang.*;
import classes.*;

public interface ILab
{
	
    void addLab(String a);
	void removeLab(String a);
	void searchLab(String a);
	void showLablist();

}