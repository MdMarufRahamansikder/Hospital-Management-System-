import java.lang.*;
import classes.*;
import interfaces.*;
import java.util.*;


public class Start
{
	public static void main(String args[])
	{
		Homepage hp = new Homepage();
		hp.setVisible(true);
	}
}
